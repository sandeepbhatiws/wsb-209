import React from 'react'

export default function EnquiryData({userInformation}) {
    return (
        <>
            <div className="col-lg-8">
                <div className="card border-0 shadow-lg" style={{ borderRadius: '15px', overflow: 'hidden' }}>
                    <div style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }} className="text-white p-4">
                        <h4 className="mb-0 fw-bold">📊 Recent Enquiries</h4>
                    </div>
                    <div className="card-body p-0">
                        <div className="table-responsive">
                            <table className="table mb-0">
                                <thead style={{ backgroundColor: '#f0f0f0' }}>
                                    <tr>
                                        <th className="fw-bold text-secondary">ID</th>
                                        <th className="fw-bold text-secondary">Name</th>
                                        <th className="fw-bold text-secondary">Email</th>
                                        <th className="fw-bold text-secondary">Subject</th>
                                        <th className="fw-bold text-secondary">Date</th>
                                        <th className="fw-bold text-secondary">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr style={{ borderBottom: '1px solid #e0e0e0' }}>
                                        <td className="fw-bold" style={{ color: '#667eea' }}>001</td>
                                        <td>John Doe</td>
                                        <td>john@example.com</td>
                                        <td>Website Development</td>
                                        <td>2025-01-15</td>
                                        <td><span className="badge" style={{ backgroundColor: '#fff3cd', color: '#856404' }}>⏳ Pending</span></td>
                                    </tr>
                                    <tr style={{ borderBottom: '1px solid #e0e0e0' }}>
                                        <td className="fw-bold" style={{ color: '#667eea' }}>002</td>
                                        <td>Jane Smith</td>
                                        <td>jane@example.com</td>
                                        <td>Mobile App</td>
                                        <td>2025-01-14</td>
                                        <td><span className="badge" style={{ backgroundColor: '#cfe2ff', color: '#084298' }}>⚙️ In Progress</span></td>
                                    </tr>
                                    <tr style={{ borderBottom: '1px solid #e0e0e0' }}>
                                        <td className="fw-bold" style={{ color: '#667eea' }}>003</td>
                                        <td>Robert Johnson</td>
                                        <td>robert@example.com</td>
                                        <td>Cloud Migration</td>
                                        <td>2025-01-13</td>
                                        <td><span className="badge" style={{ backgroundColor: '#d1e7dd', color: '#0f5132' }}>✓ Completed</span></td>
                                    </tr>
                                    <tr style={{ borderBottom: '1px solid #e0e0e0' }}>
                                        <td className="fw-bold" style={{ color: '#667eea' }}>004</td>
                                        <td>Emily Davis</td>
                                        <td>emily@example.com</td>
                                        <td>UI/UX Design</td>
                                        <td>2025-01-12</td>
                                        <td><span className="badge" style={{ backgroundColor: '#fff3cd', color: '#856404' }}>⏳ Pending</span></td>
                                    </tr>
                                    <tr style={{ borderBottom: '1px solid #e0e0e0' }}>
                                        <td className="fw-bold" style={{ color: '#667eea' }}>005</td>
                                        <td>Michael Brown</td>
                                        <td>michael@example.com</td>
                                        <td>Data Analytics</td>
                                        <td>2025-01-11</td>
                                        <td><span className="badge" style={{ backgroundColor: '#cfe2ff', color: '#084298' }}>⚙️ In Progress</span></td>
                                    </tr>
                                    <tr>
                                        <td className="fw-bold" style={{ color: '#667eea' }}>006</td>
                                        <td>Sarah Wilson</td>
                                        <td>sarah@example.com</td>
                                        <td>API Development</td>
                                        <td>2025-01-10</td>
                                        <td><span className="badge" style={{ backgroundColor: '#d1e7dd', color: '#0f5132' }}>✓ Completed</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
